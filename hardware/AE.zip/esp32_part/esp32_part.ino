#include <Arduino.h>

#include "AppConfig.h"
#include "MqttService.h"

MqttService mqttService;
unsigned long lastTelemetryMs = 0;
float data[5] = {69, 420, 69, 69, 69};
void setup()
{
  Serial.begin(115200);
  Serial2.begin(115200, SERIAL_8N1, 16, 17);
  delay(2000);

  mqttService.begin();
}

void loop()
{
  mqttService.loop();

  const unsigned long now = millis();

  if (now - lastTelemetryMs >= AppConfig::TelemetryIntervalMs)
  {
    lastTelemetryMs = now;
    mqttService.publishTelemetry(data[0], data[1], data[2], data[3], data[4]);
  }

  size_t len = Serial2.readBytes((uint8_t *)data, sizeof(data));

  if (len == sizeof(data))
  {
    Serial.println();
    Serial.println();
    Serial.println("#### Paquete recibido ####");
    Serial.print("Voltaje: ");
    Serial.println(data[0]);
    Serial.print("Intensidad: ");
    Serial.println(data[1]);
    Serial.print("Potencia: ");
    Serial.println(data[2]);
    Serial.print("Factor de potencia: ");
    Serial.println(data[3]);
    Serial.print("Fase: ");
    Serial.println(data[4]);
    Serial.println();
    Serial.println();
  }
}